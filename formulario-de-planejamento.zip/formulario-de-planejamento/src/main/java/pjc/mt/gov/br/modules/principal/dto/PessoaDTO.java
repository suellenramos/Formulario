package pjc.mt.gov.br.modules.principal.dto;


import lombok.Data;

@Data
public class PessoaDTO
{
    private Long id;
    private String nome;
    private Integer matricula;
    private String unidade;

}
