package pjc.mt.gov.br.modules.principal.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class AmbienteDTO {
    private Long id;
    private String descricao;

}
