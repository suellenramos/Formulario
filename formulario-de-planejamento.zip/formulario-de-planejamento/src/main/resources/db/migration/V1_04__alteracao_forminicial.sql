ALTER TABLE public.alternativa DROP COLUMN resposta_id;




