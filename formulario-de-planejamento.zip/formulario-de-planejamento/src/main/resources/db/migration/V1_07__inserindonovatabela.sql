CREATE TABLE public.pergun_alternativa (
	pergun_alt_id int8 NOT NULL,
	CONSTRAINT pergun_alternativa_pk PRIMARY KEY (pergun_alt_id)
);