ALTER TABLE public.resposta DROP CONSTRAINT resposta_fk_2;
ALTER TABLE public.pergunta DROP CONSTRAINT pergunta_fk;

