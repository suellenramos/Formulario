ALTER TABLE public.alternativa DROP COLUMN pergunta_id;
