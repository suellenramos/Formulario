ALTER TABLE public.formulario_pjc DROP COLUMN resposta_id;
