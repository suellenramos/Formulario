ALTER TABLE public.pergun_alternativa DROP COLUMN pergun_alt_id;
