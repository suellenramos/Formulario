DROP TABLE pergun_alternativa;
